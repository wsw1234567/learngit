#!/bin/sh

foo(){
    echo $1
}

echo $1

foo 2

echo $1

exit 0
