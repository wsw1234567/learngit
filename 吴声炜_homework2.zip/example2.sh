#!/bin/sh

echo "script starting"

foo(){
    echo "Function foo is executing"
}

foo

echo "script ended"

exit 0
